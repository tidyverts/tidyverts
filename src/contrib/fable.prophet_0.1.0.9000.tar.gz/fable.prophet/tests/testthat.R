library(testthat)
library(fable.prophet)

test_check("fable.prophet")
