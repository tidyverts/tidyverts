context("Configure test options")
options(cli.unicode = FALSE)
