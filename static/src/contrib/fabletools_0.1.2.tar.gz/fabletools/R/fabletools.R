#' @docType package
#' @keywords package
"_PACKAGE"

globalVariables(".")

#' @import rlang
#' @import tsibble
#' @importFrom dplyr mutate transmute summarise filter select rename group_by ungroup groups group_data anti_join left_join semi_join
#' @importFrom tidyr nest unnest gather spread
NULL