autoplot.gam <- function(object, date_var = "date", ...){
  tmp <- tempfile()
  png(filename=tmp)
  p <- plot(object, ..., select = 1)
  dev.off()
  unlink(tmp)

  ymin <- min(map_dbl(p, ~min(.$fit - .$se, na.rm = TRUE)))
  ymax <- max(map_dbl(p, ~max(.$fit + .$se, na.rm = TRUE)))

  map2(p, object$smooth, function(x, smooth){
    edf <- sum(object$edf[smooth$first.para:smooth$last.para])

    if(grepl(date_var, smooth$term)){
      x$x <- as.Date(x$x, origin = "1970-01-01")
      x$raw <- as.Date(x$raw, origin = "1970-01-01")
    }

    ggplot(NULL) +
      geom_smooth(aes(x = x$x, y = x$fit,
                      ymin = x$fit - x$se, ymax = x$fit + x$se),
                  stat = "identity") +
      geom_rug(aes(x = x$raw, y = NULL), sides = "b") +
      labs(x = smooth$term, y = sprintf("s(%s, %.2f)", smooth$term, edf)) +
      ylim(c(ymin, ymax))
  })
}
