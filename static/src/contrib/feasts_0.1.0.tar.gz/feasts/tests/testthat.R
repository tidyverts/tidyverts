library(testthat)
library(feasts)

test_check("feasts")
