library(tidyverse)
library(lubridate)
library(tsibble)
library(xml2)

# Bore data
nsw_bores <- map_dfr(
  list.files("data-raw/Boredata/", pattern = ".*\\.csv", full.names = TRUE),
  read_csv,
  col_types = cols(
    Site = col_character(),
    Hole = col_double(),
    Pipe = col_double(),
    `Date time` = col_character(),
    `Below Measuring Point` = col_double(),
    `Below Ground Level` = col_double(),
    `Above Sea Level` = col_double()
  )
) %>%
  filter(!is.na(`Below Measuring Point`)) %>%
  mutate(datetime = dmy_hm(`Date time`)) %>%
  transmute(site = Site, hole = Hole, pipe = Pipe, datetime,
            below_measuring_point = `Below Measuring Point`,
            below_ground_level = `Below Ground Level`,
            above_sea_level = `Above Sea Level`) %>%
  # Remove duplicated section of data from a bore
  distinct(site, hole, pipe, datetime, below_measuring_point, .keep_all = TRUE)

nsw_bores <- as_tsibble(nsw_bores, key = c(site, hole, pipe), index = datetime)

# count_gaps(nsw_bores)

# # Provided bore meta information is unsuitable for data analysis
# library(readxl)
# bore_meta <- read_excel("Boredata/Overview of info about 32  Dept Alstonville monitoring bores.xlsx", skip = 2)

# Instead use xml data from realtimedata.waternsw.com.au
nsw_bores_meta <- read_xml("https://realtimedata.waternsw.com.au/wgen/sites.gw.anon.xml")
nsw_bores_meta <- map_dfr(
  xml_find_all(nsw_bores_meta, "//site"),
  compose(as_tibble, as.list, xml_attrs)
) %>%
  separate(station, c("site", "hole", "pipe"), sep = "\\.") %>%
  mutate_at(
    c("hole", "pipe", "latdec", "lngdec"),
    as.numeric
  )

usethis::use_data(nsw_bores, overwrite = TRUE)
usethis::use_data(nsw_bores_meta, overwrite = TRUE)
