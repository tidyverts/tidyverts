library(tidyverse)
library(lubridate)
library(tsibble)
library(stringr)

# SILO rain data
nsw_rain <- read_lines("data-raw/RainfallData/58131.txt")[c(-(1:35), -37)] %>%
  str_replace_all("\\s{1,}", ",") %>%
  read_csv() %>%
  transmute(
    ID = "58131",
    date = ymd(Date),
    temp_max = T.Max,
    temp_min = T.Min,
    rain_amt_mm = Rain,
    evaporation = Evap,
    solar_radiation = Radn,
    rel_humidity_tmax = RHmaxT,
    rel_humidity_tmin = RHminT
  ) %>%
  as_tsibble(index = date)

# # BOM Rain data
# nsw_rain <- map_dfr(
#   list.files("data-raw/RainfallData/", pattern = ".*\\.csv", full.names = TRUE),
#   read_csv,
#   col_types = cols(
#     `Product code` = col_character(),
#     `Bureau of Meteorology station number` = col_double(),
#     Year = col_double(),
#     Month = col_double(),
#     Day = col_double(),
#     `Rainfall amount (millimetres)` = col_double(),
#     `Period over which rainfall was measured (days)` = col_double(),
#     Quality = col_character()
#   )
# ) %>%
#   transmute(
#     station_number = `Bureau of Meteorology station number`,
#     date = ymd(paste(Year, Month, Day)),
#     rain_amt_mm = `Rainfall amount (millimetres)`,
#     rain_continuous_days = replace_na(`Period over which rainfall was measured (days)`, 0)
#   ) %>%
#   filter(!is.na(rain_amt_mm))
#
#
# # Overlapping sensor period
# nsw_rain %>%
#   group_by(station_number) %>%
#   summarise(min(date), max(date))
#
# # Average overlapping period to give long term rain history
# nsw_rain <- nsw_rain %>%
#   select(-rain_continuous_days) %>%
#   spread(station_number, rain_amt_mm) %>%
#   transmute(date, rain_amt_mm = case_when(
#     is.na(`58023`) ~ `58131`,
#     is.na(`58131`) ~ `58023`,
#     TRUE ~ (`58131` + `58023`)/2
#   )) %>%
#   as_tsibble(index = date)

# count_gaps(nsw_rain)

usethis::use_data(nsw_rain, overwrite = TRUE)
