triangle_area <- function(Ax, Bx, Cx, Ay, By, Cy) {
  0.5 * abs((Ax - Cx) * (By - Ay) - (Ax - Bx) * (Cy - Ay))
}

lttb <- function(idx, x, n_bins, focus_limits = NULL, focus_bins = NULL){
  n <- length(x)

  if(!is.null(focus_limits)){
    focus <- (idx >= focus_limits[1]) & (idx <= focus_limits[2])
    # Crude approximation at focus boundaries
    out <- logical(n)
    out[!focus] <- lttb(idx[!focus], x[!focus], n_bins)
    out[focus] <- lttb(idx[focus], x[focus], focus_bins)
    return(out)
  }

  bin_width <- (n - 2)/n_bins
  if (n <= n_bins + 2) {
    return(rep_len(TRUE, n))
  }

  out <- logical(n)
  out[1] <- TRUE
  out[n] <- TRUE
  for (i in 1 + seq_len(n_bins)) {
    Ax <- i - 1
    Ay <- out[Ax]
    Ax <- as.POSIXct(idx[Ax])
    if (i < n_bins) {
      Cx <- floor(i * bin_width + seq_len(bin_width))
      Cy <- mean(x[Cx])
      Cx <- as.POSIXct(mean(idx[Cx]))
      Bi <- floor(((i - 1) * bin_width + 1):(i * bin_width))
      By <- x[Bi]
      Bx <- as.POSIXct(idx[Bi])
    }
    else {
      C <- x[n]
      Bi <- floor(((i - 1) * bin_width + 1):(n - 1))
      By <- x[Bi]
      Bx <- as.POSIXct(idx[Bi])
    }
    triangle_areas <- triangle_area(Ax, Bx, Cx, Ay, By, Cy)
    out[Bi[which.max(triangle_areas)]] <- TRUE
  }
  return(out)
}

#' Sveinn Steinarsson's LTTB time series downsampling method
#'
#' @param data A tsibble.
#' @param y The variable used to downsample on.
#' @param size The number of rows to select.
#'
#' @import tsibble
#' @import dplyr
#' @import rlang
#'
#' @export
#' @rdname lttb
sample_lttb <- function(data, y, size = 1000){
  data %>%
    group_by_key() %>%
    filter(lttb(!!index(data), {{y}}, n_bins = size - 2))
}

#' @rdname lttb
#' @export
focus_lttb <- function(data, y, size, focus_limits, focus_size){
  data %>%
    group_by_key() %>%
    filter(lttb(!!index(data), {{y}}, size - 2, focus_limits, focus_size - 2))
}
