#' @keywords package
"_PACKAGE"

globalVariables(".")

#' @import rlang
#' @import tsibble
#' @importFrom dplyr mutate transmute summarise group_by ungroup filter distinct lead
#' @importFrom tidyr gather
NULL

